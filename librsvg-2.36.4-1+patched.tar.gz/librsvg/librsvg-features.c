#include "rsvg.h"

/* General initialization hooks */
const guint librsvg_major_version = LIBRSVG_MAJOR_VERSION;
const guint librsvg_minor_version = LIBRSVG_MINOR_VERSION;
const guint librsvg_micro_version = LIBRSVG_MICRO_VERSION;
const char librsvg_version[] = LIBRSVG_VERSION;
